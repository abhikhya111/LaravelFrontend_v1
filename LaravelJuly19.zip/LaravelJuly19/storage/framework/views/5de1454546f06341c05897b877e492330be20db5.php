<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <link href="/css/style.css" rel="stylesheet"/>

  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_sidebar.html -->
      <?php echo $__env->make('partials/Sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
      
        <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
          <div class="navbar-menu-wrapper d-flex align-items-stretch">
          </div>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">Images of Products</h3>

            </div>
            <button type="button"  class="btn btn-warning"> <a href="/api/createCategory" style="color:white" >Add Category </a></button>
            <br>
            <br>
            <div class="row">
            
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Product Images</h4>
                    
                    <div class="table-responsive">
                    
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>Product Name</th>
                            <th>Image 1</th>
                            <th>Image 2</th>
                            <th>Image 3</th>
                            <th>Image 4</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($img->product_name); ?></td>
                            <td>
                            
                              <?php if(empty($img->image1)): ?>
                              <form action="<?php echo e(route('addImage', ['product_id'=>$img->product_id,'name'=>'image1'])); ?>" method="POST">  
                                  <label>Enter image SRC</label>
                                  <input  type="text" class="form-control" name="img_src" placeholder="Enter image src"/>
                                  <button class="btn btn-primary" style="margin-top:20px" type="submit">Save</button>
                              </form>
                                  <?php else: ?>
                                  <img src="<?php echo e($img->image1); ?>" alt="Upload Imaged"/>

                                  <form action="<?php echo e(route('removeImage', ['product_id'=>$img->product_id,'name'=>'image1'])); ?>" method="POST">  
                                    <?php echo csrf_field(); ?>  
                                    
                                    <button class="btn btn-success" type="submit">Remove</button>  
                                </form>
                              <?php endif; ?>
                            
                                
                                    
                            </td>
                              


                          <td>
                          <?php if(empty($img->image2)): ?>
                              <form action="<?php echo e(route('addImage', ['product_id'=>$img->product_id,'name'=>'image2'])); ?>" method="POST">  
                                  <label>Enter image SRC</label>
                                  <input  type="text" class="form-control" name="img_src" placeholder="Enter image src"/>
                                  <button class="btn btn-primary" style="margin-top:20px" type="submit">Save</button>
                              </form>
                                  <?php else: ?>
                                  <img src="<?php echo e($img->image2); ?>" alt="Upload Imaged"/>

                                  <form action="<?php echo e(route('removeImage', ['product_id'=>$img->product_id,'name'=>'image2'])); ?>" method="POST">  
                                    <?php echo csrf_field(); ?>  
                                    
                                    <button class="btn btn-success" type="submit">Remove</button>  
                                </form>
                              <?php endif; ?>
                        
                          </td>
                           

                            <td> <?php if(empty($img->image3)): ?>
                              <form action="<?php echo e(route('addImage', ['product_id'=>$img->product_id,'name'=>'image3'])); ?>" method="POST">  
                                  <label>Enter image SRC</label>
                                  <input  type="text" class="form-control" name="img_src" placeholder="Enter image src"/>
                                  <button class="btn btn-primary" style="margin-top:20px" type="submit">Save</button>
                              </form>
                                  <?php else: ?>
                                  <img src="<?php echo e($img->image3); ?>" alt="Upload Imaged"/>

                                  <form action="<?php echo e(route('removeImage', ['product_id'=>$img->product_id,'name'=>'image3'])); ?>" method="POST">  
                                    <?php echo csrf_field(); ?>  
                                    
                                    <button class="btn btn-success" type="submit">Remove</button>  
                                </form>
                              <?php endif; ?>

                            </td>
                            
                            <td>
                            <?php if(empty($img->image4)): ?>
                              <form action="<?php echo e(route('addImage', ['product_id'=>$img->product_id,'name'=>'image4'])); ?>" method="POST">  
                                  <label>Enter image SRC</label>
                                  <input  type="text" class="form-control" name="img_src" placeholder="Enter image src"/>
                                  <button class="btn btn-primary" style="margin-top:20px" type="submit">Save</button>
                              </form>
                                  <?php else: ?>
                                  <img src="<?php echo e($img->image4); ?>" alt="Upload Imaged"/>

                                  <form action="<?php echo e(route('removeImage', ['product_id'=>$img->product_id,'name'=>'image4'])); ?>" method="POST">  
                                    <?php echo csrf_field(); ?>  
                                    
                                    <button class="btn btn-success" type="submit">Remove</button>  
                                </form>
                              <?php endif; ?>
                            </td>
                            

                    

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             
             
          
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH C:\Users\abhikhyaa\Downloads\LaravelBackend-main (3)\LaravelBackend-main\LaravelBackend_June27\LaravelBackend_June27\resources\views/productImages/showProductImages.blade.php ENDPATH**/ ?>